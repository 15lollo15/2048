/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048nn;

import java.util.Scanner;
import javax.swing.JFrame;
import pkg2048.*;
import reti.neurali.*;

/**
 *
 * @author Lorenzo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        GeneticNeuralNetwork gnn = new GeneticNeuralNetwork(10, 16, 16, 4);
        Matrix2048 matrix = new Matrix2048();
        JFrame f = new JFrame();
        PannelloPrincipale p = new PannelloPrincipale(matrix,500);
        
        Scanner in = new Scanner(System.in);
        int move;
        
        gnn.setMutationRate(1);
        
        
        f.add(p);
        f.pack();
        f.setVisible(true);
        
        for(int k = 0; k<100000; k++){
            for(int i = 0; i<10; i++){
                System.out.println("Rete " + i);
                
                do{
                    p.repaint();
                    matrix.addNumber();

                    double[] input = toArray(matrix);
                    double[] output = gnn.getNNAt(i).predict(input);

                    move = indexMax(output);
                    //matrix.stampa();
                    //System.out.println();
                    //Thread.sleep(1000);
                    //Thread.sleep(50);
                    if(matrix.update(Matrix2048.Direction.toDirection(move)) == false)
                        if(matrix.isFull())
                            break;
                }while(true);
                p.repaint();
                System.out.println("Score: " + matrix.getScore());
                gnn.getNNAt(i).setFitness(matrix.getScore());
                //in.next();
                //Thread.sleep(1000);
                matrix.clear();
            }
            gnn.naturalSelection();
            //in.next();
            //System.out.print(gnn.getNNAt(1));
        }
        
    }
    
    public static int indexMax(double[] a){
        int max = 0;
        for(int i = 1; i<a.length; i++)
            if(a[max] < a[i]) max = i;
        return max;
    }
    
    public static double[] toArray(Matrix2048 m){
        double[] array = new double[m.L*m.L];
        
        int index = 0;
        for(int i = 0; i<m.L; i++)
            for(int j = 0; j<m.L; j++)
                array[index++] = m.getAt(i, j);
        return array;
    }
    
}
