/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048nn;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.io.Writer;
import java.util.Scanner;
import javax.swing.JFrame;
import pkg2048.*;
import reti.neurali.*;

/**
 *
 * @author Lorenzo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        GeneticNeuralNetwork gnn = new GeneticNeuralNetwork(10, 16, 24, 4);
        Matrix2048 matrix = new Matrix2048();
        JFrame f = new JFrame();
        PannelloPrincipale p = new PannelloPrincipale(matrix,500);
        
        Scanner in = new Scanner(System.in);
        int move;
        
        gnn.setMutationRate(0.1);
        
        
        f.add(p);
        f.pack();
        //f.setVisible(true);
        
        int best = 0;
        
        for(int k = 0; k<100000; k++){
            
            int time = 0;
            if(k >= 20000){
                f.setVisible(true);
                time = 10;
            }
            
            for(int i = 0; i<10; i++){
                //System.out.println("Rete " + i);
                
                do{
                    p.repaint();
                    matrix.addNumber();

                    double[] input = toArray(matrix);
                    double[] output = gnn.getNNAt(i).predict(input);

                    move = indexMax(output);
                    //matrix.stampa();
                    //System.out.println();
                    //Thread.sleep(1000);
                    Thread.sleep(time);
                    boolean sbloccato = false;
                    int[] array = sort(output);
                    if(matrix.update(Matrix2048.Direction.toDirection(move)) == false)
                        if(matrix.isFull()){
                            for(int j = 1; j<array.length && !sbloccato; j++){
                                move = array[j];
                                if(matrix.update(Matrix2048.Direction.toDirection(move)))
                                    sbloccato = true;
                            }
                            if(!sbloccato)
                                break;
                        }
                }while(true);
                p.repaint();
                //System.out.println("Score: " + matrix.getScore());
                gnn.getNNAt(i).setFitness(matrix.getScore());
                //in.next();
                
                //Tread.sleep(1000);
                matrix.clear();
            }
            gnn.naturalSelection();
            System.out.println(k + " Best of ALL: " + gnn.getBest().getFitness());
            
            if(gnn.getBest().getFitness() > best){
                best = (int) gnn.getBest().getFitness();
                writeNN(String.valueOf(best)+".dat",gnn.getBest());
            }
            //in.next();
            //System.out.print(gnn.getNNAt(1));
        }

        
        /*
        int[] a2 = sort(new double[]{1,2,3,4,5});
        
        for(int i = 0; i<a2.length; i++)
            System.out.println(a2[i]);
         */   
        
    }
    
    public static int indexMax(double[] a){
        int max = 0;
        for(int i = 1; i<a.length; i++)
            if(a[max] < a[i]) max = i;
        return max;
    }
    
    public static double[] toArray(Matrix2048 m){
        double[] array = new double[m.L*m.L];
        
        int index = 0;
        for(int i = 0; i<m.L; i++)
            for(int j = 0; j<m.L; j++)
                array[index++] = m.getAt(i, j);
        return array;
    }
    
    public static int[] sort(double[] a){
        int[] a2 = new int[a.length];
        
        for(int i = 0; i<a.length; i++)
            a2[i] = i;
        
        for(int i = 0; i<a.length; i++){
            for(int j = i+1; j<a.length; j++){
                if(a[a2[i]] < a[a2[j]]){
                    int tmp = a2[i];
                    a2[i] = a2[j];
                    a2[j] = tmp;
                }
            }
        }
        
        return a2;
    }
    
    public static void writeNN(String path, NeuralNetwork n){
        try{
            FileOutputStream fos = new FileOutputStream(path);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(n);
            
            oos.close();
        }catch(Exception e){};
    }
    
}
