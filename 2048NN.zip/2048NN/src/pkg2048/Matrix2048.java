/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

/**
 *
 * @author Lorenzo
 */
public class Matrix2048 {
    
    public final static int L = 4;
    
    private int[][] matrix; 
    
    private int score;
    
    public static enum Direction{
        UP,DOWN,RIGHT,LEFT;
        
        public static Direction toDirection(int v){
            switch(v){
                case 0:
                    return UP;
                case 1:
                    return DOWN;
                case 2:
                    return RIGHT;
                case 3:
                    return LEFT;
            }
            return null;
        }
    }
    
    public Matrix2048(){
        matrix = new int[L][L];
        
        score = 0;
        
        for(int i = 0; i<L ;i++) matrix[i] = new int[L];
        
        for(int i = 0; i<L; i++)
            for(int j = 0; j<L; j++)
                matrix[i][j] = 0;
    }
    
    public boolean addNumber(){
        int i,j;
        
        if(isFull()) return false;
        
        i = randomWithRange(0, L);
        j = randomWithRange(0, L);
        
        while(matrix[i][j] != 0){
            i = randomWithRange(0, L);
            j = randomWithRange(0, L);
        }
        
        matrix[i][j] = 2;
        return true;
    }
    
    public boolean isFull(){
        for(int i = 0; i<L; i++){
            for(int j = 0; j<L ; j++)
                if(matrix[i][j] == 0)
                    return false;
        }
        return true;
    }
    
    public void stampa(){
        for(int i = 0; i<L; i++){
            for(int j = 0; j<L; j++){
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
    }
    
    private int randomWithRange(int min, int max){
       int range = (max - min);     
       return (int)(Math.random() * range) + min;
    }
    
    public int getScore(){
        return score;
    }
    
    public boolean update(Direction d){
        boolean isSomethingUpdated = false;
        boolean isMoved = true;
        switch(d){
            case UP:
                for(int col = 0; col < L; col++){
                    isMoved = true;
                    while(isMoved){
                        isMoved = false;
                        for(int row = 0; row < L-1; row++){
                            if(matrix[row][col] == 0 && matrix[row+1][col] != 0){
                                matrix[row][col] = matrix[row+1][col];
                                matrix[row+1][col] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }else if(matrix[row][col] != 0 && matrix[row+1][col] == matrix[row][col]){
                                matrix[row][col] = matrix[row][col]*2;
                                score += matrix[row][col];
                                matrix[row+1][col] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }
                        }
                    }
                }
                break;
            case DOWN:
                for(int col = 0; col < L; col++){
                    isMoved = true;
                    while(isMoved){
                        isMoved = false;
                        for(int row = L-1; row > 0; row--){
                            if(matrix[row][col] == 0 && matrix[row - 1][col] != 0){
                                matrix[row][col] = matrix[row-1][col];
                                matrix[row - 1][col] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }else if(matrix[row][col] != 0 && matrix[row-1][col] == matrix[row][col]){
                                matrix[row][col] = matrix[row][col]*2;
                                score += matrix[row][col];
                                matrix[row-1][col] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }
                        }
                    }
                }
                break;
            case RIGHT:
                for(int row = 0; row < L; row++){
                    isMoved = true;
                    while(isMoved){
                        isMoved = false;
                        for(int col = L-1; col > 0 ; col--){
                            if(matrix[row][col] == 0 && matrix[row][col-1] != 0){
                                matrix[row][col] = matrix[row][col-1];
                                matrix[row][col - 1] = 0;
                                isSomethingUpdated = true;
                                isMoved = true; 
                            }else if(matrix[row][col] != 0 && matrix[row][col-1] == matrix[row][col]){
                                matrix[row][col] = matrix[row][col]*2;
                                score += matrix[row][col];
                                matrix[row][col-1] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }
                        }
                    }
                }
                break;
            case LEFT:
                for(int row = 0; row < L; row++){
                    isMoved = true;
                    while(isMoved){
                        isMoved = false;
                        for(int col = 0; col < L-1; col++){
                            if(matrix[row][col] == 0 && matrix[row][col+1] != 0){
                                matrix[row][col] = matrix[row][col+1];
                                matrix[row][col + 1] = 0;
                                isSomethingUpdated = true;
                                isMoved = true; 
                            }else if(matrix[row][col] != 0 && matrix[row][col+1] == matrix[row][col]){
                                matrix[row][col] = matrix[row][col]*2;
                                score += matrix[row][col];
                                matrix[row][col+1] = 0;
                                isSomethingUpdated = true;
                                isMoved = true;
                            }
                        }
                    }
                }
                break;
        }
        return isSomethingUpdated;
    }
    
    public int getAt(int row, int col){
        return matrix[row][col];
    }
    
    public void clear(){
        score = 0;
        for(int i = 0; i<L; i++)
            for(int j = 0; j<L; j++)
                matrix[i][j] = 0;
    }
    
}
