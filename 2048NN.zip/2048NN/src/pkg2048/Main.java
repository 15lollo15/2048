/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Lorenzo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Matrix2048 m = new Matrix2048();
        Scanner in = new Scanner(System.in);
        JFrame f = new JFrame();
        PannelloPrincipale p = new PannelloPrincipale(m,500);
        
        m.addNumber();
        m.addNumber();
        
        
        
        
        
        m.stampa();

        f.add(p);
        
        f.pack();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        /*
        while(true){
            int c = in.nextInt();
            
        while(true){
            int c = in.nex
            if(m.update(Matrix2048.Direction.toDirection(c))){
                if(!m.addNumber())
                    break;
                p2.repaint();
            }
        }
        */
        
    }
    
}
