/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

/**
 *
 * @author Lollo
 */
public class PannelloPrincipale extends JPanel implements KeyListener{
    private Panel2048 p2048;
    private Matrix2048 matrix;
    private JLabel scoreLabel;
    
    public PannelloPrincipale(Matrix2048 matrix, int l){
        this.matrix = matrix;
        p2048 = new Panel2048(matrix,l);
        
        this.setLayout(new BorderLayout());
        
        scoreLabel = new JLabel("0");
        
        scoreLabel.setHorizontalAlignment(JLabel.CENTER);
        scoreLabel.setVerticalAlignment(JLabel.CENTER);
        scoreLabel.setFont(new Font("Consolas",Font.BOLD,30));
        
        this.add(scoreLabel, BorderLayout.NORTH);
        this.add(p2048, BorderLayout.CENTER);
        
        this.addKeyListener(this);
        this.setFocusable(true);
    }
    
        @Override
    public void keyTyped(KeyEvent ke) {
        return;
    }

    @Override
    public void keyPressed(KeyEvent ke) {
        
        if(ke.getKeyCode() == KeyEvent.VK_UP){
            if(matrix.update(Matrix2048.Direction.UP)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_DOWN){
            if(matrix.update(Matrix2048.Direction.DOWN)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_RIGHT){
            if(matrix.update(Matrix2048.Direction.RIGHT)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_LEFT){
            if(matrix.update(Matrix2048.Direction.LEFT)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }
        scoreLabel.setText(String.valueOf(matrix.getScore()));
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        return;
    }
}
