/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reti.neurali;

/**
 *
 * @author Lorenzo
 */
public class MatrixOutOfBoundException extends ArrayIndexOutOfBoundsException{

    public MatrixOutOfBoundException(String s) {
        super(s);
    }

    public MatrixOutOfBoundException() {
        super();
    }
    
}
