package reti.neurali;

public class NeuralNetwork {
    private int iNeuron;
    private int hNeuron;
    private int oNeuron;
    
    private double fitness = 0;
    
    private Matrix weightsIH;
    private Matrix weightsHO;
    private Matrix biasIH;
    private Matrix biasHO;
    
    private double learingRate = 0.1;

    public double getFitness() {
        return fitness;
    }

    public void setFitness(double fitness) {
        this.fitness = fitness;
    }
    
    
    
    public NeuralNetwork(int iNeuron, int hNeuron, int oNeuron) {
        this.iNeuron = iNeuron;
        this.hNeuron = hNeuron;
        this.oNeuron = oNeuron;
        
        weightsIH = new Matrix(hNeuron, iNeuron);
        weightsHO = new Matrix(oNeuron, hNeuron);
        weightsIH.randomize();
        weightsHO.randomize();
        
        biasIH = new Matrix(hNeuron, 1);
        biasHO = new Matrix(oNeuron, 1);
        biasIH.randomize();
        biasHO.randomize();
    }
    
    
    public NeuralNetwork(NeuralNetwork nn){
        iNeuron = nn.iNeuron;
        hNeuron = nn.hNeuron;
        oNeuron = nn.oNeuron;
        weightsIH = new Matrix(nn.weightsIH);
        weightsHO = new Matrix(nn.weightsHO);
        biasIH = new Matrix(nn.biasIH);
        biasHO = new Matrix(nn.biasHO);
        learingRate = nn.learingRate;
        fitness = nn.fitness;
    }
    
    public void setLearingRate(double learingRate) {
        this.learingRate = learingRate;
    }

    public double getLearingRate() {
        return learingRate;
    }
    
    public double sigmoid(double x){
        return 1 / (1 + Math.exp(-x));
    }
    
    public double[] predict(double[] input){
        Matrix inputs = new Matrix(input);
        Matrix hidden = Matrix.multiplication(weightsIH, inputs);
        hidden.add(biasIH);
        //System.out.println(hidden);
        
        applySigmoid(hidden);
        
        Matrix output = Matrix.multiplication(weightsHO, hidden);
        output.add(biasHO);
        applySigmoid(output);
        
        return output.toArray();
    }
    
    public void applySigmoid(Matrix m){
        for(int i = 0; i < m.getRow(); i++)
            for(int j = 0; j<m.getCol(); j++)
                m.setAt(i, j, sigmoid(m.getAt(i, j)));
    }
    
    public Matrix returnSigmoidAt(Matrix m){
        Matrix m2 = new Matrix(m);
        
        applySigmoid(m2);
        
        return m2;
    }
    
    public void train(double[] input, double[] target){
        Matrix inputs = new Matrix(input);
        Matrix hidden = Matrix.multiplication(weightsIH, inputs);
        hidden.add(biasIH);
        applySigmoid(hidden);
        
        Matrix outputs = Matrix.multiplication(weightsHO, hidden);
        outputs.add(biasHO);
        applySigmoid(outputs);
        
        Matrix targets = new Matrix(input);
        Matrix outputErrors = Matrix.subtract(targets, outputs);
        
        Matrix gradients = returnSigmoidAt(outputs);
        gradients = Matrix.multiplication(gradients, outputErrors);
        gradients.multiply(learingRate);
        
        Matrix hiddenT = Matrix.transpose(hidden);
        Matrix weightHODeltas = Matrix.multiplication(gradients, hiddenT);
        
        weightsHO.add(weightHODeltas);
        biasHO.add(gradients);
        
        Matrix whoT = Matrix.transpose(weightsHO);
        Matrix hiddenErrors = Matrix.multiplication(whoT, outputErrors);
        
        Matrix hiddenGradient = returnSigmoidAt(hidden);
        hiddenGradient = Matrix.multiplication(hiddenGradient, hiddenErrors);
        hiddenGradient.multiply(learingRate);
        
        Matrix inputsT = Matrix.transpose(inputs);
        Matrix weightsIHDeltas = Matrix.multiplication(hiddenGradient, inputsT);
        
        weightsIH.add(weightsIHDeltas);
        biasIH.add(hiddenGradient);
    }
    
    public static NeuralNetwork haveSex(NeuralNetwork n1, NeuralNetwork n2, double mutationProbability){
        if(!n1.isCompatible(n2)){
            System.out.println("Nope");
            return null;
        }
        NeuralNetwork n3 = new NeuralNetwork(n1);
        for(int i = 0; i<n3.weightsIH.getRow(); i++)
            for(int j = 0; j < n3.weightsIH.getCol(); j++){
                if(Math.random() > mutationProbability){
                    if( i % 2 == 0 && j % 2 == 1)
                        n3.weightsIH.setAt(i, j, n1.weightsIH.getAt(i, j));
                    else
                        n3.weightsIH.setAt(i, j, n2.weightsIH.getAt(i, j));
                }else{
                    n3.weightsIH.setAt(i, j, n3.weightsIH.getAt(i,j) + (randomWithRange(-10000,10000)));
                }
            }
        
        for(int i = 0; i<n3.weightsHO.getRow(); i++)
            for(int j = 0; j < n3.weightsHO.getCol(); j++){
                if(Math.random() > mutationProbability){
                    if( i % 2 == 0 && j % 2 == 1)
                        n3.weightsHO.setAt(i, j, n1.weightsHO.getAt(i, j));
                    else
                        n3.weightsHO.setAt(i, j, n2.weightsHO.getAt(i, j));
                }else{
                    n3.weightsHO.setAt(i, j, n3.weightsHO.getAt(i,j) + (randomWithRange(-10000,10000)));
                }
            }
        
        for(int i = 0; i<n3.biasHO.getRow(); i++)
            for(int j = 0; j < n3.biasHO.getCol(); j++){
                if(Math.random() > mutationProbability){
                    if( i % 2 == 0 && j % 2 == 1)
                        n3.biasHO.setAt(i, j, n1.biasHO.getAt(i, j));
                    else
                        n3.biasHO.setAt(i, j, n2.biasHO.getAt(i, j));
                }else{
                    n3.biasHO.setAt(i, j, n3.biasHO.getAt(i, j) + (randomWithRange(-10000,10000)));
                }
            }
        
        for(int i = 0; i<n3.biasIH.getRow(); i++)
            for(int j = 0; j < n3.biasIH.getCol(); j++){
                if(Math.random() > mutationProbability){
                    if( i % 2 == 0 && j % 2 == 1)
                        n3.biasIH.setAt(i, j, n1.biasIH.getAt(i, j));
                    else
                        n3.biasIH.setAt(i, j, n2.biasIH.getAt(i, j));
                }else{
                    n3.biasIH.setAt(i, j, n3.biasIH.getAt(i,j) + (randomWithRange(-10000,10000)));
                    //System.out.println("Fatto");
                }
            }
        
        return n3;
    }
    
    private static double randomWithRange(int min, int max){
       int range = (max - min);     
       return (Math.random() * range) + min;
    }
    
    public boolean isCompatible(NeuralNetwork n2){
        return (n2.iNeuron == iNeuron && n2.hNeuron == hNeuron && n2.oNeuron == oNeuron);
    }
    
}
