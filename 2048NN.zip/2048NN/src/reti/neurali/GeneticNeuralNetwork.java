package reti.neurali;

import java.util.ArrayList;

public class GeneticNeuralNetwork {
    private NeuralNetwork[] nn;
    private int numNN;
    private int iLayer;
    private int hLayer;
    private int oLayer;
    
    private double mutationRate = 0.02;

    public double getMutationRate() {
        return mutationRate;
    }

    public void setMutationRate(double mutationRate) {
        this.mutationRate = mutationRate;
    }
    
    
    
    public NeuralNetwork getNNAt(int i){
        return nn[i];
    }
    
    public GeneticNeuralNetwork(int numNN, int iLayer, int hLayer, int oLayer){
        if(numNN%2 == 1)
            numNN++;
        
        nn = new NeuralNetwork[numNN];
        
        this.numNN = numNN;
        
        for(int i = 0; i<numNN; i++)
            nn[i] = new NeuralNetwork(iLayer, hLayer, oLayer);
    }
    
    public void naturalSelection(double[] fitness){
        for(int i = 0; i<numNN; i++)
            nn[i].setFitness(fitness[i]);
        sort();
        
        ArrayList<NeuralNetwork> newNN = new ArrayList();
        
        for(int i = 1; i< numNN/2; i++){
            newNN.add(NeuralNetwork.haveSex(nn[i], nn[i-1], mutationRate));
            newNN.add(NeuralNetwork.haveSex(nn[i-1], nn[i], mutationRate));
            newNN.add(nn[i]);
            newNN.add(nn[i-1]);
        }
        nn = (NeuralNetwork[])newNN.toArray();
    }
    
    public void naturalSelection(){
        sort();
        
        ArrayList<NeuralNetwork> newNN = new ArrayList();
        //System.out.println("ciao");
        for(int i = 1; i< numNN/2; i++){
            //System.out.println("ciao");
            newNN.add(NeuralNetwork.haveSex(nn[i], nn[i-1], mutationRate));
            newNN.add(NeuralNetwork.haveSex(nn[i-1], nn[i], mutationRate));
            newNN.add(nn[i]);
            newNN.add(nn[i-1]);
            //System.out.println("ciao");
        }
        nn = new NeuralNetwork[numNN];
        for(int i = 0; i<numNN; i++)
            nn[i] = newNN.get(i);
    }
    
    private void sort(){
        for(int i = 0; i<numNN; i++){
            for(int j = i+1; j<numNN; j++){
                if(nn[i].getFitness() < nn[j].getFitness()){
                    NeuralNetwork tmp = nn[i];
                    nn[i] = nn[j];
                    nn[j] = tmp;
                }
            }
        }
    }
    
    public void stampaOrdinata(){
        sort();
        for(int i = 0; i<numNN; i++){
            System.out.println("Rete " + i + " " + nn[i].getFitness());
        }
    }
}
