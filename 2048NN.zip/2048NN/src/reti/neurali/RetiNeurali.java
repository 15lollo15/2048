/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reti.neurali;

/**
 *
 * @author Lorenzo
 */
public class RetiNeurali {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Matrix m1 = new Matrix(2,1);
        Matrix m2 = new Matrix(2,2);
        
        m1.setAt(0, 0, 1);
        m1.setAt(1, 0, 2);
        
        System.out.println(m1);
        
        m2.setAt(0, 0, 5);
        m2.setAt(0, 1, 6);
        m2.setAt(1, 0, 7);
        m2.setAt(1, 1, 8);
        
        System.out.println(m2);
        
        System.out.println(Matrix.multiplication(m2, m1));
        */
        
        NeuralNetwork nn = new NeuralNetwork(2,2,1);
        
        double[] out = nn.predict(new double[]{1,0});
        
        System.out.println(out[0]);
        
    }
    
}
