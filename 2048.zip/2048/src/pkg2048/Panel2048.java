/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javafx.scene.input.KeyCode;
import javax.swing.*;
import sun.java2d.loops.FillRect;

/**
 *
 * @author Lorenzo
 */
public class Panel2048 extends JPanel{
    private Matrix2048 matrix = null;
    int l;
    
    private Color[] colors;
    
    public Panel2048(Matrix2048 matrix, int l){
        super();
        
        this.matrix = matrix;
        
        this.l = l - (l%Matrix2048.L);
        
        this.setLayout(null);
        this.setPreferredSize(new Dimension(l,l));
        
        impostaColori();
        
        
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
        
        for(int row = 0; row < matrix.L; row++){
            for(int col = 0; col < matrix.L; col++){
                if(matrix.getAt(row, col) == 0){
                    g.setColor(Color.white);
                }else{
                    g.setColor(colors[toTwo(matrix.getAt(row,col))]);
                }
                g.fillRect((l/matrix.L)*col, (l/matrix.L)*row, l/matrix.L, l/matrix.L);
                g.setColor(Color.white);
                g.setFont(new Font("Comic Sans MS", Font.PLAIN, (l/matrix.L)/3));
                g.drawString(String.valueOf(matrix.getAt(row, col)), ((l/matrix.L)*col) + (((l/matrix.L)/4)), ((l/matrix.L)*row) + ((l/matrix.L)/2));
            }
        }
        
    }
    
    private void impostaColori(){
        colors = new Color[12];
        
        colors[1] = new Color(252,178,7);
        colors[2] = new Color(170,252,7);
        colors[3] = new Color(7,252,32);
        colors[4] = new Color(7,252,252);
        colors[5] = new Color(7,23,252);
        colors[6] = new Color(174,7,252);
        colors[7] = new Color(252,7,178);
        colors[8] = new Color(252,7,11);
        colors[9] = new Color(91,4,6);
        colors[10] = new Color(4,14,91);
        colors[11] = new Color(4,91,77);
        
    }
    
    private int toTwo(int i){
        int tmp = 2;
        int cont = 1;
        while(tmp != i){ 
            tmp*=2;
            cont++;
        }
        return cont;
    }

    
    public Matrix2048 getMatrix(){
        return matrix;
    }
}
