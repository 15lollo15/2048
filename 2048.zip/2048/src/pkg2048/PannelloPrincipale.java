/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

/**
 *
 * @author Lollo
 */
public class PannelloPrincipale extends JPanel implements KeyListener{
    private Panel2048 p2048;
    private Matrix2048 matrix;
    
    
    public PannelloPrincipale(Matrix2048 matrix, int l){
        this.matrix = matrix;
        p2048 = new Panel2048(matrix,l);
        
        this.add(p2048);
        
        this.addKeyListener(this);
        this.setFocusable(true);
    }
    
        @Override
    public void keyTyped(KeyEvent ke) {
        return;
    }

    @Override
    public void keyPressed(KeyEvent ke) {
        
        if(ke.getKeyCode() == KeyEvent.VK_UP){
            if(matrix.update(Matrix2048.Direction.UP)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_DOWN){
            if(matrix.update(Matrix2048.Direction.DOWN)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_RIGHT){
            if(matrix.update(Matrix2048.Direction.RIGHT)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }else if(ke.getKeyCode() == KeyEvent.VK_LEFT){
            if(matrix.update(Matrix2048.Direction.LEFT)){
                matrix.addNumber();
                p2048.repaint();
            }     
        }
        System.out.println(matrix.getScore());
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        return;
    }
}
